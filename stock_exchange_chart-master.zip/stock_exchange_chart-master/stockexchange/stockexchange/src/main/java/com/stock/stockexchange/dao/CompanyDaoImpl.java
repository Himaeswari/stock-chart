package com.stock.stockexchange.dao;

public class CompanyDaoImpl {

}
