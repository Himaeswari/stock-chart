package com.stock.stockexchange.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.stockexchange.dao.LoginDao;
import com.stock.stockexchange.model.User;


@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	LoginDao loginDao;
	
	@Override
	public User validateAdmin(int user, String password) throws SQLException
	{
		
      
	  User check= loginDao.validateAdmin(user,password);
	  System.out.println("hi "+check);
	  return check;
	}
	
}
