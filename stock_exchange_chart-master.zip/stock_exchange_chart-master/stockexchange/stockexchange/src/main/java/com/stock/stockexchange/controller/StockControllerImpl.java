package com.stock.stockexchange.controller;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.stock.stockexchange.model.Stock;
import com.stock.stockexchange.service.StockService;

@Controller
public class StockControllerImpl {

	@Autowired
	private StockService stockService;
	
	@RequestMapping(value = "/addStock", method = RequestMethod.GET)
	public String getStockForm(ModelMap model) {
		System.out.println("add stock");
		Stock stock=new Stock();
		
		model.addAttribute("stock", stock);
		return "addStock";
	}
	
	@RequestMapping(value = "/addStock", method = RequestMethod.POST)
	public String processStockForm(@Valid @ModelAttribute("stock") Stock stock, BindingResult result,
			 Model model){
		
		
		
		System.out.println(stock);
		if(result.hasErrors())
		{
			System.out.println("eror");
		    model.addAttribute("stock",stock);
		    return "addStock";
		}
		try
		{
		stockService.insertStock(stock);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	
		return "redirect:/stockList";
	}
	
	@RequestMapping(path="/stockList")
	public ModelAndView getStockList() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("stockList");
		mv.addObject("stockList",stockService.getStockList());
		return mv;
	}
	
	@RequestMapping(value="/updateStock")
	public ModelAndView edit(@RequestParam("stockExchangeId") int id, ModelMap model) 
	{
		ModelAndView mav=null;
            try
			{
		    Stock stock = stockService.getStockById(id);
			model.addAttribute("stock", stock);
		    }
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		
		mav=new ModelAndView("stockEdit");
		
		return mav;
	}
	
	@RequestMapping(value="/deleteStock")
	public String delete(@RequestParam("stockExchangeId") int id, ModelMap model) 
	{
		
            try
			{
		     stockService.deleteStockById(id);
			
		    }
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		
		
		return "redirect:/stockList";
	}
	
	@RequestMapping(value="/updateStockSave")
	public String editsave(@ModelAttribute("stock") Stock stock)
			
	{
		try
		{
		stockService.insertStock(stock);
	    }
		
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		return "redirect:/stockList";
	}
}
