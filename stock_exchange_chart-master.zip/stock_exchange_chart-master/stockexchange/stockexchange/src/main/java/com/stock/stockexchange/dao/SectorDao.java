package com.stock.stockexchange.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.Sector;


public interface SectorDao extends JpaRepository<Sector,Integer>{

	

	@Query("Select c From Sector c")
	List<Sector> fetchSector();
}
